# -*- coding: utf-8 -*-
"""Watch history tracking — stores last N watched items with deduplication."""

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs
import re

MAX_HISTORY = 50


def _get_active_profile_num(addon):
    raw = addon.getSetting("active_pvr_profile") or "Profile 1"
    match = re.search(r"(\d+)$", raw)
    try:
        return int(match.group(1)) if match else 1
    except Exception:
        return 1


class WatchHistory:
    def __init__(self, addon=None, profile_num=None):
        if addon is None:
            addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.exists(profile):
            os.makedirs(profile)
        pnum = profile_num if profile_num is not None else _get_active_profile_num(addon)
        if profile_num is None:
            xbmc.log(
                f"[XStream Player] Warning: WatchHistory instantiated without profile_num, falling back to PVR profile {pnum}",
                xbmc.LOGWARNING,
            )
        self._path = os.path.join(profile, f"watch_history_p{pnum}.json")
        self._items = self._load()

    def _load(self):
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def _save(self):
        tmp_file = self._path + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(self._items, f, ensure_ascii=False)
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_file, self._path)

    def add(self, name, url, icon="", stype="live", extra=None):
        """Add an item to history. Deduplicates by name+stype, most recent first."""
        entry = {
            "name": name,
            "url": url,
            "icon": icon,
            "stype": stype,
            "timestamp": time.time(),
        }
        if extra and isinstance(extra, dict):
            entry.update(extra)
        # Remove existing entry with same name+stype
        self._items = [
            i
            for i in self._items
            if not (i.get("name") == name and i.get("stype") == stype)
        ]
        # Insert at front
        self._items.insert(0, entry)
        # Trim
        self._items = self._items[:MAX_HISTORY]
        self._save()

    def get_all(self, stype=None):
        """Return history items, optionally filtered by type."""
        if stype:
            return [i for i in self._items if i.get("stype") == stype]
        return list(self._items)

    def clear(self):
        self._items = []
        self._save()

    def remove(self, name, stype=None):
        """Remove a specific item from history."""
        if stype:
            self._items = [
                i
                for i in self._items
                if not (i.get("name") == name and i.get("stype") == stype)
            ]
        else:
            self._items = [i for i in self._items if i.get("name") != name]
        self._save()

    def clear_by_type(self, stype):
        """Clear all history items of a specific type."""
        self._items = [i for i in self._items if i.get("stype") != stype]
        self._save()


class ResumePoints:

    def __init__(self, addon=None, profile_num=None):
        if addon is None:
            addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.exists(profile):
            os.makedirs(profile)
        if profile_num is None:
            pnum = _get_active_profile_num(addon)
            xbmc.log(
                f"[XStream Player] Warning: ResumePoints instantiated without profile_num, falling back to PVR profile {pnum}",
                xbmc.LOGWARNING,
            )
        else:
            pnum = profile_num
        self._path = os.path.join(profile, f"resume_points_p{pnum}.json")
        self._finished_path = os.path.join(profile, f"finished_p{pnum}.json")
        self._data = self._load(self._path)
        # Separate store: which (name, url) pairs were watched to
        # (near-)completion. Kept apart from resume-point data so a
        # finished marker never gets misread as an active, resumable
        # position/duration by callers like get_entry().
        self._finished = self._load(self._finished_path)

    def _load(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _save(self, path, data):
        tmp_file = path + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_file, path)

    def _key(self, name, url):
        return f"{name}||{url}"

    def save_position(self, name, url, position, duration, icon=""):
        """Save playback position. Only saves if >60s in and not near the end.

        icon is stored alongside so Continue Watching still has a poster
        for this item even if its watch-history entry (which normally
        supplies the icon) later gets evicted by WatchHistory's own
        MAX_HISTORY cap -- previously resume points carried no icon at
        all, so anything that fell out of watch history that way lost its
        thumbnail permanently."""
        if position < 60 or duration < 120:
            return
        key = self._key(name, url)
        if position > duration * 0.93:
            # Near end — mark as finished, remove resume point
            self._data.pop(key, None)
            self._save(self._path, self._data)
            self._finished[key] = {"name": name, "url": url, "timestamp": time.time()}
            self._save(self._finished_path, self._finished)
            return
        entry = {
            "name": name,
            "url": url,
            "position": position,
            "duration": duration,
            "timestamp": time.time(),
        }
        if icon:
            entry["icon"] = icon
        elif key in self._data and self._data[key].get("icon"):
            # Keep whatever icon a previous save already had rather than
            # dropping it just because this particular call didn't pass one.
            entry["icon"] = self._data[key]["icon"]
        self._data[key] = entry
        self._save(self._path, self._data)
        if key in self._finished:
            # Rewatching something previously finished — let it show as
            # in-progress again instead of staying hidden forever.
            self._finished.pop(key, None)
            self._save(self._finished_path, self._finished)

    def get_position(self, name, url):
        """Return saved position in seconds, or 0 if none."""
        entry = self._data.get(self._key(name, url))
        if entry:
            return entry.get("position", 0)
        return 0

    def get_entry(self, name, url):
        """Return the full {position, duration, ...} dict, or None if no
        resume point is saved -- unlike get_position(), also exposes
        duration, needed to compute a percentage-played for display."""
        return self._data.get(self._key(name, url))

    def is_finished(self, name, url):
        """Return True if this (name, url) was watched to (near-)completion
        and hasn't been rewatched since."""
        return self._key(name, url) in self._finished

    def toggle_finished(self, name, url):
        """Manually flip the finished marker for a (name, url) pair, same
        one save_position() sets automatically near the end of playback.
        For Continue Watching items with no series_id/season_num/ep_id to
        toggle WatchedEpisodes with (a resume point saved with no matching
        watch-history entry) -- this is keyed the same way resume points
        themselves are, so it always applies regardless of that gap."""
        key = self._key(name, url)
        if key in self._finished:
            self._finished.pop(key, None)
        else:
            self._finished[key] = {"name": name, "url": url, "timestamp": time.time()}
            self._data.pop(key, None)
            self._save(self._path, self._data)
        self._save(self._finished_path, self._finished)

    def remove(self, name, url):
        self._data.pop(self._key(name, url), None)
        self._save(self._path, self._data)

    def clear(self):
        self._data = {}
        self._save(self._path, self._data)
        self._finished = {}
        self._save(self._finished_path, self._finished)


class WatchedMovies:

    def __init__(self, addon=None, profile_num=None):
        if addon is None:
            addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.exists(profile):
            os.makedirs(profile)
        pnum = (
            profile_num if profile_num is not None else _get_active_profile_num(addon)
        )
        if profile_num is None:
            xbmc.log(
                f"[XStream Player] Warning: WatchedMovies instantiated without profile_num, falling back to PVR profile {pnum}",
                xbmc.LOGWARNING,
            )
        self._path = os.path.join(profile, f"watched_movies_p{pnum}.json")
        self._data = self._load()

    def _load(self):
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _save(self):
        tmp_file = self._path + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False)
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_file, self._path)

    def mark_watched(self, stream_id):
        """Mark a movie as watched."""
        self._data[str(stream_id)] = True
        self._save()

    def mark_unwatched(self, stream_id):
        """Mark a movie as unwatched."""
        self._data.pop(str(stream_id), None)
        self._save()

    def is_watched(self, stream_id):
        """Check if a movie has been watched."""
        return str(stream_id) in self._data

    def clear(self):
        self._data = {}
        self._save()


class WatchedEpisodes:

    def __init__(self, addon=None, profile_num=None):
        if addon is None:
            addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.exists(profile):
            os.makedirs(profile)
        pnum = (
            profile_num if profile_num is not None else _get_active_profile_num(addon)
        )
        if profile_num is None:
            xbmc.log(
                f"[XStream Player] Warning: WatchedEpisodes instantiated without profile_num, falling back to PVR profile {pnum}",
                xbmc.LOGWARNING,
            )
        self._path = os.path.join(profile, f"watched_episodes_p{pnum}.json")
        self._data = self._load()

    def _load(self):
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _save(self):
        tmp_file = self._path + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False)
            try:
                f.flush()
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_file, self._path)

    def mark_watched(self, series_id, season_num, episode_id):
        """Mark an episode as watched."""
        key = str(series_id)
        if key not in self._data:
            self._data[key] = {}
        season = str(season_num)
        if season not in self._data[key]:
            self._data[key][season] = []
        ep_id = str(episode_id)
        if ep_id not in self._data[key][season]:
            self._data[key][season].append(ep_id)
            self._save()

    def mark_unwatched(self, series_id, season_num, episode_id):
        """Mark an episode as unwatched."""
        key = str(series_id)
        season = str(season_num)
        if key in self._data and season in self._data[key]:
            ep_id = str(episode_id)
            if ep_id in self._data[key][season]:
                self._data[key][season].remove(ep_id)
                self._save()

    def is_watched(self, series_id, season_num, episode_id):
        """Check if an episode has been watched."""
        key = str(series_id)
        season = str(season_num)
        return str(episode_id) in self._data.get(key, {}).get(season, [])

    def get_watched_count(self, series_id, season_num=None):
        """Get count of watched episodes for a series or season."""
        key = str(series_id)
        if key not in self._data:
            return 0
        if season_num is not None:
            return len(self._data[key].get(str(season_num), []))
        return sum(len(eps) for eps in self._data[key].values())

    def clear_series(self, series_id):
        """Clear all watched data for a series."""
        key = str(series_id)
        if key in self._data:
            del self._data[key]
            self._save()

    def mark_season_watched(self, series_id, season_num, episode_ids):
        """Mark all episodes in a season as watched."""
        key = str(series_id)
        if key not in self._data:
            self._data[key] = {}
        season = str(season_num)
        if season not in self._data[key]:
            self._data[key][season] = []
        for ep_id in episode_ids:
            ep_str = str(ep_id)
            if ep_str not in self._data[key][season]:
                self._data[key][season].append(ep_str)
        self._save()

    def mark_season_unwatched(self, series_id, season_num):
        """Mark all episodes in a season as unwatched."""
        key = str(series_id)
        season = str(season_num)
        if key in self._data and season in self._data[key]:
            del self._data[key][season]
            self._save()

    def is_season_fully_watched(self, series_id, season_num, total_episodes):
        """Check if all episodes in a season are watched."""
        return self.get_watched_count(series_id, season_num) >= total_episodes

    def clear(self):
        self._data = {}
        self._save()
